@echo off
echo Iniciando Escaner Facial de Emociones...
C:\venv_fc\Scripts\python.exe "%~dp0faceCAM.py"
pause
